"use strict";

const HUB_URL='https://bloxdio-turnier-rangliste.vercel.app/pending.html';
const BLOXD_URL='https://bloxd.io/play/classic_playerSchematic%7CHT_Y95VcEQaUBLbTc24H7?lobby=1';
const REG_INGEST_URL='https://nxzrgbpaxukgjyzwupjp.supabase.co/functions/v1/hub-extension-assertion-ingest';
const LIVE_INGEST_URL='https://nxzrgbpaxukgjyzwupjp.supabase.co/functions/v1/hub-extension-live-ingest';
const MAX_RECENT=80,MAX_LIVE_RECENT=120;
const DEFAULT_STATE={bloxdSeenAt:0,totalAssertionsObserved:0,totalAssertionsUploaded:0,recentAssertions:[],uploadedKeys:[],latestRegistrationCode:null,latestSelfCode:null,latestUpload:null,totalLiveObserved:0,totalLiveUploaded:0,recentLive:[],latestLiveUpload:null,relayMode:'hub-verify-full-relay',uploadEnabled:true,hubLanguage:'en',identityNames:{},ownDbId:null};
const snapshotBuffers=new Map();

async function getState(){return{...DEFAULT_STATE,...await chrome.storage.local.get(DEFAULT_STATE)};}
async function setState(patch){await chrome.storage.local.set(patch);return getState();}
function cleanCode(value){const code=String(value||'').toUpperCase().replace(/[^A-Z0-9]/g,'');return /^[A-Z0-9]{8}$/.test(code)?code:'';}
function cleanRegRaw(value){const raw=String(value||'').trim();if(!raw.startsWith('__SG_EVT__|REGASSERT|')||raw.length>4000)return'';return raw;}
function cleanLiveRaw(value){const raw=String(value||'').trim();if(!raw.startsWith('__SG_EVT__|')||raw.startsWith('__SG_EVT__|REG')||!raw.includes('|SIG=')||raw.length>7000)return'';return raw;}
function rawKey(raw){let h=2166136261;for(let i=0;i<raw.length;i+=1)h=Math.imul(h^raw.charCodeAt(i),16777619);return String(h>>>0);}
function rawCode(raw){const p=String(raw||'').split('|');return p.length===8?cleanCode(p[5]):'';}
function safeDecode(value){try{return decodeURIComponent(String(value||''));}catch(_){return String(value||'');}}
function rawIdentity(raw){const p=String(raw||'').split('|');return p.length===8?{dbId:safeDecode(p[3]).trim(),playerName:safeDecode(p[4]).trim(),code:cleanCode(p[5])}:null;}
function markerType(raw){return String(raw||'').split('|')[1]||'';}
function markerMatchId(raw){return String(raw||'').split('|')[2]||'';}
async function badge(){const state=await getState();const active=Date.now()-Number(state.bloxdSeenAt||0)<120000;const text=active?'ON':'';await chrome.action.setBadgeText({text});if(text)await chrome.action.setBadgeBackgroundColor({color:'#55e6b1'});}
async function post(url,body){const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});let data={};try{data=await response.json();}catch(_){}if(!response.ok||!data?.ok)throw new Error(data?.error||`HTTP ${response.status}`);return data;}
async function recordLive(raw,status,result=null,error=null){const state=await getState(),key=rawKey(raw),recent=Array.isArray(state.recentLive)?state.recentLive:[],existing=recent.find(x=>x?.key===key),now=Date.now();const totalObserved=Number(state.totalLiveObserved||0)+(existing?0:1),totalUploaded=Number(state.totalLiveUploaded||0)+(status==='uploaded'&&!existing?1:0);const item={key,type:markerType(raw),matchId:markerMatchId(raw),seenAt:existing?.seenAt||now,status,uploadedAt:status==='uploaded'?now:null,error:error?String(error):null};const next=[item,...recent.filter(x=>x?.key!==key)].slice(0,MAX_LIVE_RECENT);return setState({bloxdSeenAt:now,totalLiveObserved:totalObserved,totalLiveUploaded:totalUploaded,recentLive:next,latestLiveUpload:{ok:status==='uploaded',seenAt:now,event:result?.event||item.type,error:error?String(error):null}});}
async function uploadSingleLive(raw){try{const result=await post(LIVE_INGEST_URL,{raw});await recordLive(raw,'uploaded',result);return{ok:true,result};}catch(error){await recordLive(raw,'error',null,error);return{ok:false,error:String(error?.message||error)};}}
async function handleSnapshotMarker(raw){const type=markerType(raw),matchId=markerMatchId(raw);if(!matchId)return{ok:false,error:'missing_match_id'};if(type==='SNAPBEGIN'){snapshotBuffers.set(matchId,{markers:[raw],startedAt:Date.now()});await recordLive(raw,'buffered');return{ok:true,buffered:true};}const buf=snapshotBuffers.get(matchId);if(!buf)return{ok:false,error:'snapshot_buffer_missing'};buf.markers.push(raw);if(buf.markers.length>102){snapshotBuffers.delete(matchId);return{ok:false,error:'snapshot_too_large'};}if(type!=='SNAPEND'){await recordLive(raw,'buffered');return{ok:true,buffered:true};}snapshotBuffers.delete(matchId);try{const result=await post(LIVE_INGEST_URL,{markers:buf.markers});for(const marker of buf.markers)await recordLive(marker,'uploaded',result);return{ok:true,result};}catch(error){for(const marker of buf.markers)await recordLive(marker,'error',null,error);return{ok:false,error:String(error?.message||error)};}}

chrome.runtime.onInstalled.addListener(async()=>{const old=await chrome.storage.local.get(null);await chrome.storage.local.set({...DEFAULT_STATE,totalAssertionsObserved:Number(old.totalAssertionsObserved||0),totalAssertionsUploaded:Number(old.totalAssertionsUploaded||0),recentAssertions:Array.isArray(old.recentAssertions)?old.recentAssertions.slice(0,MAX_RECENT):[],uploadedKeys:Array.isArray(old.uploadedKeys)?old.uploadedKeys.slice(-500):[],latestRegistrationCode:old.latestRegistrationCode||null,latestSelfCode:cleanCode(old.latestSelfCode||'')||null,totalLiveObserved:Number(old.totalLiveObserved||0),totalLiveUploaded:Number(old.totalLiveUploaded||0),recentLive:Array.isArray(old.recentLive)?old.recentLive.slice(0,MAX_LIVE_RECENT):[],hubLanguage:['en','de','fr'].includes(old.hubLanguage)?old.hubLanguage:'en',identityNames:(old.identityNames&&typeof old.identityNames==='object')?old.identityNames:{},ownDbId:old.ownDbId?String(old.ownDbId):null});await badge();});
chrome.runtime.onStartup.addListener(badge);

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{(async()=>{const type=String(message?.type||'');
  if(type==='BLOXD_EXTENSION_READY'){const state=await setState({bloxdSeenAt:Date.now(),relayMode:'hub-verify-full-relay',uploadEnabled:true});await badge();sendResponse({ok:true,state});return;}
  if(type==='BLOXD_EXTENSION_HEARTBEAT'){const state=await setState({bloxdSeenAt:Date.now(),relayMode:'hub-verify-full-relay',uploadEnabled:true});await badge();sendResponse({ok:true,state});return;}
  if(type==='BLOXD_REGSELF_CODE'){const code=cleanCode(message.code);if(!code){sendResponse({ok:false,error:'invalid_self_code'});return;}const state=await setState({bloxdSeenAt:Date.now(),latestSelfCode:code});await badge();sendResponse({ok:true,state});return;}
  if(type==='BLOXD_GLOBAL_REGASSERT'){
    const raw=cleanRegRaw(message.raw);if(!raw){sendResponse({ok:false,error:'invalid_regassert'});return;}
    const state=await getState(),key=rawKey(raw),code=rawCode(raw),identity=rawIdentity(raw),recent=Array.isArray(state.recentAssertions)?state.recentAssertions:[],existing=recent.find(x=>x&&x.key===key);let total=Number(state.totalAssertionsObserved||0),next=recent;if(!existing){total+=1;next=[{key,seenAt:Date.now(),uploadStatus:'pending'},...recent].slice(0,MAX_RECENT);}
    try{
      const uploadedKeys=Array.isArray(state.uploadedKeys)?state.uploadedKeys:[],known=await post(REG_INGEST_URL,{mode:'status',code});
      const identityNames=(state.identityNames&&typeof state.identityNames==='object')?{...state.identityNames}:{};
      const oldName=identity?.dbId?String(identityNames[identity.dbId]||known.playerName||''):'';
      const selfCode=cleanCode(state.latestSelfCode||state.latestRegistrationCode?.code||'');
      let ownDbId=state.ownDbId?String(state.ownDbId):null;
      if(selfCode&&code===selfCode&&identity?.dbId)ownDbId=identity.dbId;
      if(known.linked===true&&identity?.playerName&&String(known.playerName||'')===identity.playerName){
        if(identity?.dbId)identityNames[identity.dbId]=identity.playerName;
        const now=Date.now(),updatedKeys=uploadedKeys.includes(key)?uploadedKeys:[...uploadedKeys,key].slice(-500),updatedRecent=next.map(x=>x?.key===key?{...x,uploadStatus:'already-linked',uploadedAt:now}:x),updated=await setState({bloxdSeenAt:now,totalAssertionsObserved:total,recentAssertions:updatedRecent,uploadedKeys:updatedKeys,identityNames,ownDbId});await badge();sendResponse({ok:true,silent:true,duplicate:true,uploaded:false,totalObserved:updated.totalAssertionsObserved,totalUploaded:Number(updated.totalAssertionsUploaded||0)});return;
      }
      const result=await post(REG_INGEST_URL,{raw}),now=Date.now(),newName=String(identity?.playerName||result.playerName||'');
      const renamed=Boolean(result.playerLinked===true&&oldName&&newName&&oldName!==newName);
      if(identity?.dbId&&newName)identityNames[identity.dbId]=newName;
      const updatedKeys=uploadedKeys.includes(key)?uploadedKeys:[...uploadedKeys,key].slice(-500),updatedRecent=next.map(x=>x?.key===key?{...x,uploadStatus:renamed?'renamed':'uploaded',uploadedAt:now}:x),uploadedCount=Number(state.totalAssertionsUploaded||0)+(existing?0:1),notifyRename=Boolean(renamed&&ownDbId&&identity?.dbId===ownDbId),notifyVerified=Boolean(selfCode&&code===selfCode&&result.pendingVerification==='verified'),notificationType=notifyRename?'rename':notifyVerified?'verified':'none',notifySelf=notificationType!=='none',updated=await setState({bloxdSeenAt:now,totalAssertionsObserved:total,totalAssertionsUploaded:uploadedCount,recentAssertions:updatedRecent,uploadedKeys:updatedKeys,identityNames,ownDbId,latestUpload:{ok:true,seenAt:now}});await badge();sendResponse({ok:true,silent:!notifySelf,notifySelf,notificationType,verifiedPlayerName:notifyVerified?(result.playerName||newName):null,renameFrom:notifyRename?oldName:null,renameTo:notifyRename?newName:null,duplicate:Boolean(existing||result.duplicate),totalObserved:updated.totalAssertionsObserved,totalUploaded:updated.totalAssertionsUploaded,uploaded:true});return;
    }catch(error){const now=Date.now(),updatedRecent=next.map(x=>x?.key===key?{...x,uploadStatus:'error',uploadedAt:now}:x),updated=await setState({bloxdSeenAt:now,totalAssertionsObserved:total,recentAssertions:updatedRecent,latestUpload:{ok:false,error:String(error?.message||error),seenAt:now}});await badge();sendResponse({ok:false,silent:true,error:String(error?.message||error),totalObserved:updated.totalAssertionsObserved,uploaded:false});return;}
  }
  if(type==='BLOXD_LIVE_MARKER'){
    const raw=cleanLiveRaw(message.raw);if(!raw){sendResponse({ok:false,error:'invalid_live_marker'});return;}
    const mt=markerType(raw);const result=(mt==='SNAPBEGIN'||mt==='SNAPPLAYER'||mt==='SNAPEND')?await handleSnapshotMarker(raw):await uploadSingleLive(raw);await badge();sendResponse({...result,silent:true});return;
  }
  if(type==='BLOXD_REGISTRATION_CODE'){const code=cleanCode(message.code);if(!code){sendResponse({ok:false,error:'invalid_code'});return;}const now=Date.now(),state=await setState({bloxdSeenAt:now,latestRegistrationCode:{code,seenAt:now}});await badge();try{const status=await post(REG_INGEST_URL,{mode:'status',code});if(status.linked===true)sendResponse({ok:true,state,notifySelf:true,verifiedPlayerName:status.playerName||null});else sendResponse({ok:true,state,silent:true});}catch(_){sendResponse({ok:true,state,silent:true});}return;}
  if(type==='HUB_EXTENSION_GET_STATE'){sendResponse({ok:true,version:chrome.runtime.getManifest().version,state:await getState()});return;}
  if(type==='HUB_EXTENSION_CLEAR'){snapshotBuffers.clear();const state=await setState({totalAssertionsObserved:0,totalAssertionsUploaded:0,recentAssertions:[],uploadedKeys:[],latestRegistrationCode:null,latestSelfCode:null,latestUpload:null,totalLiveObserved:0,totalLiveUploaded:0,recentLive:[],latestLiveUpload:null});sendResponse({ok:true,state});return;}
  if(type==='OPEN_HUB'){await chrome.tabs.create({url:HUB_URL});sendResponse({ok:true});return;}
  if(type==='OPEN_BLOXD'){await chrome.tabs.create({url:BLOXD_URL});sendResponse({ok:true});return;}
  sendResponse({ok:false,error:'unknown_message'});
})().catch(error=>{console.error('[HUB Verify Relay]',error);try{sendResponse({ok:false,silent:true,error:String(error?.message||error)});}catch(_){}});return true;});
